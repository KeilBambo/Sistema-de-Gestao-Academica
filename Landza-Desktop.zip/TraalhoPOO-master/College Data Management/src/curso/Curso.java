package curso;

public class Curso {

	private String codigoCurso;
	private int semouano;
	private boolean isdeclared;
	private String nomeCurso;
	public void setNomeCurso(String nomeCurso)
	{
		this.nomeCurso=nomeCurso;
	}
	public void setCodigoCurso(String codigoCurso)
	{
		this.codigoCurso=codigoCurso;
	}
	public void setSemouano(int semouano)
	{
		this.semouano=semouano;
	}
	public void setIsDeclared(boolean isdeclared)
	{
		this.isdeclared=isdeclared;
	}
	public String getNomeCurso()
	{
		return nomeCurso!=null?nomeCurso:new DadosCurso().getcourcename(codigoCurso);
	}
	public String getCodigoCurso()
	{
		return codigoCurso;
	}
	public int getSemouano()
	{
		return semouano;
	}
	public boolean getIsDeclared()
	{
		return isdeclared;
	}
}
