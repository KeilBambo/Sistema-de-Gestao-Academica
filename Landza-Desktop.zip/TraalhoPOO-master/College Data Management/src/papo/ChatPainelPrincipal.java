package papo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import comuns.ImageUtil;
import docente.DocenteMain;
import estudante.EstudanteMain;

import javax.swing.border.MatteBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;

import admin.Admin;
import admin.AdminDados;
import admin.AdminPrincipal;

import java.awt.Cursor;


@SuppressWarnings("serial")
public class ChatPainelPrincipal extends JPanel {

	/**
	 * 
	 */
	
	public PainelChat chatpanel;
	private PainelListaContactos contactlistpanel;
	public ChatInfoPainel chatinfopanel;
	private JScrollPane contactlistpanelscroll;
	private JPanel panel;
	public JTextField searchfield;
	private JLabel profilepiclabel;
	public AdminPrincipal am;
	public DocenteMain fm;
	public EstudanteMain sm;
	private JLabel onlinestatus;
	MyDocumentListener fielddoc=new MyDocumentListener();
	private JLabel hintlabel;
	
	public ChatPainelPrincipal(AdminPrincipal am)
	{
		this();
		this.am=am;
		
		contactlistpanel=new PainelListaContactos(am,this);
		contactlistpanel.setBounds(0, 0, 330, 600);
		contactlistpanelscroll.setViewportView(contactlistpanel);
		contactlistpanelscroll.setVisible(true);
		add(contactlistpanelscroll);
		
		chatpanel=new PainelChat();
		chatpanel.setSize(500, 705);
		chatpanel.setLocation(330, 0);
		chatpanel.setVisible(true);
		add(chatpanel);
		
		Admin admin=new AdminDados().getAdminData();
		chatpanel.setFromUserData("Admin", "Principal",admin.getProfilePic());
		BufferedImage image=ImageUtil.toBufferedImage(admin.getProfilePic(50, 50));
		profilepiclabel.setIcon(new ImageIcon(ImageUtil.makeRoundedCorner(image, 50)));
		chatinfopanel.setData(admin);
		chatinfopanel.setAdmin(new AdminDados().getAdminData());
		profilepiclabel.addMouseListener(new MouseAdapter()
		{
			public void mousePressed(MouseEvent e)
			{
				if(e.getButton()==MouseEvent.BUTTON1)
				{
					chatinfopanel.setData(admin);
					chatpanel.setEmptyChatPanel();
					for(JPanel panel:contactlistpanel.contactlist)
					{
						panel.setBackground(Color.white);
						
						for(Component c:panel.getComponents())
						{

							if(c.getName()!=null && c.getName().equals("lastmessage"))
							{
								if(!c.getForeground().equals(Color.DARK_GRAY))
								{
									c.setForeground(Color.gray);
								}
							}
							else if(c.getName()!=null &&c.getName().equals("messagetime")&&c.getForeground().equals(new Color(30,178,170)))
							{
								
								c.setForeground(Color.gray);
							}
							else if(c.getName()!=null&&c.getName().equals("username"))
							{
								c.setForeground(Color.DARK_GRAY);
							}
							else if(c.getName()!=null && c.getName().equals("messagetime"))
							{
								c.setForeground(Color.gray);
							}
						}
					}
				}
			}
		});
	}
	public ChatPainelPrincipal(DocenteMain fm)
	{
		this();
		this.fm=fm;
		contactlistpanel=new PainelListaContactos(fm,this);
		contactlistpanel.setBounds(0, 0, 330, 600);
		contactlistpanelscroll.setViewportView(contactlistpanel);
		contactlistpanelscroll.setVisible(true);
		add(contactlistpanelscroll);
		chatpanel=new PainelChat();
		chatpanel.setSize(500, 705);
		chatpanel.setLocation(330, 0);
		chatpanel.setVisible(true);
		add(chatpanel);
		chatpanel.setFromUserData(fm.f.getFacultyId()+"",fm.f.getFacultyName(), fm.f.getProfilePic());
		BufferedImage image=ImageUtil.toBufferedImage(fm.f.getProfilePic().getScaledInstance(50, 50, Image.SCALE_SMOOTH));
		profilepiclabel.setIcon(new ImageIcon(ImageUtil.makeRoundedCorner(image, 50)));
		chatinfopanel.setData(fm.f);
		chatinfopanel.setFaculty(fm.f);
		profilepiclabel.addMouseListener(new MouseAdapter()
		{
			public void mousePressed(MouseEvent e)
			{
				if(e.getButton()==MouseEvent.BUTTON1)
				{
					chatinfopanel.setData(fm.f);
					chatpanel.setEmptyChatPanel();
					for(JPanel panel:contactlistpanel.contactlist)
					{
						panel.setBackground(Color.white);
						for(Component c:panel.getComponents())
						{

							if(c.getName()!=null && c.getName().equals("lastmessage"))
							{
								if(!c.getForeground().equals(Color.DARK_GRAY))
								{
									c.setForeground(Color.gray);
								}
							}
							else if(c.getName()!=null &&c.getName().equals("messagetime")&&c.getForeground().equals(new Color(30,178,170)))
							{
								
								c.setForeground(Color.gray);
							}
							else if(c.getName()!=null&&c.getName().equals("username"))
							{
								c.setForeground(Color.DARK_GRAY);
							}
							else if(c.getName()!=null && c.getName().equals("messagetime"))
							{
								c.setForeground(Color.gray);
							}
						}
					}
				}
			}
		});
	}
	public ChatPainelPrincipal(EstudanteMain sm)
	{
		this();
		
		this.sm=sm;
		contactlistpanel=new PainelListaContactos(sm,this);
		contactlistpanel.setBounds(0, 0, 330, 600);
		contactlistpanelscroll.setViewportView(contactlistpanel);
		contactlistpanelscroll.setVisible(true);
		add(contactlistpanelscroll);
		
		chatpanel=new PainelChat();
		chatpanel.setSize(500, 705);
		chatpanel.setLocation(330, 0);
		chatpanel.setVisible(true);
		add(chatpanel);
		
		chatpanel.setFromUserData(sm.s.getIdusuario(), sm.s.getNomecompleto(), sm.s.getProfilePic());
		BufferedImage image=ImageUtil.toBufferedImage(sm.s.getProfilePic(50, 50));
		profilepiclabel.setIcon(new ImageIcon(ImageUtil.makeRoundedCorner(image, 50)));
		chatinfopanel.setData(sm.s);
		chatinfopanel.setStudent(sm.s);
		
		profilepiclabel.addMouseListener(new MouseAdapter()
		{
			public void mousePressed(MouseEvent e)
			{
				if(e.getButton()==MouseEvent.BUTTON1)
				{
					chatinfopanel.setData(sm.s);
					chatpanel.setEmptyChatPanel();
					for(JPanel panel:contactlistpanel.contactlist)
					{
						panel.setBackground(Color.white);
						for(Component c:panel.getComponents())
						{

							if(c.getName()!=null && c.getName().equals("lastmessage"))
							{
								if(!c.getForeground().equals(Color.DARK_GRAY))
								{
									c.setForeground(Color.gray);
								}
							}
							else if(c.getName()!=null &&c.getName().equals("messagetime")&&c.getForeground().equals(new Color(30,178,170)))
							{
								
								c.setForeground(Color.gray);
							}
							else if(c.getName()!=null&&c.getName().equals("username"))
							{
								c.setForeground(Color.DARK_GRAY);
							}
							else if(c.getName()!=null && c.getName().equals("messagetime"))
							{
								c.setForeground(Color.gray);
							}
						}
						
					}
				}
			}
		});
	}
	public ChatPainelPrincipal() {
		setBorder(new EmptyBorder(0, 0, 0, 0));
		setBackground(Color.WHITE);
		setForeground(Color.WHITE);
		this.setSize(1116, 705);
		setLayout(null);
		this.requestFocusInWindow(true);
		contactlistpanelscroll=new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		contactlistpanelscroll.setBounds(0, 60,330,645);
		contactlistpanelscroll.getVerticalScrollBar().setUnitIncrement(80);
		contactlistpanelscroll.getVerticalScrollBar().setPreferredSize(new Dimension(5,0));
		
		
		
		
		chatinfopanel=new ChatInfoPainel(); 
		chatinfopanel.setLocation(830, 0);
		chatinfopanel.setVisible(true);
		add(chatinfopanel);
		
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBorder(new MatteBorder(1, 1, 0, 0, (Color) new Color(192, 192, 192)));
		panel.setBounds(0, 0, 330, 60);
		add(panel);
		panel.setLayout(null);
		
		searchfield = new JTextField();
		searchfield.setBorder(new MatteBorder(0,0,1,0,Color.LIGHT_GRAY));
		searchfield.setLayout(new BorderLayout());
		searchfield.setForeground(Color.DARK_GRAY);
		searchfield.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		searchfield.setBounds(75, 11, 245, 38);
		searchfield.getDocument().addDocumentListener(fielddoc);
		searchfield.setFocusable(false);
		searchfield.addMouseListener(new MouseAdapter()
				{
					public void mousePressed(MouseEvent e)
					{
						searchfield.setFocusable(true);
						searchfield.grabFocus();
					}
					
				}
				);
		searchfield.setLayout(new BorderLayout());
		hintlabel=new JLabel("Search...");
		hintlabel.setFont(searchfield.getFont());
		hintlabel.setForeground(new Color(100,100,100));
		searchfield.add(hintlabel,BorderLayout.LINE_START);
		panel.add(searchfield);
		searchfield.setColumns(10);
		
		onlinestatus = new JLabel(new ImageIcon("./assets/onlinestatus.png"));
		onlinestatus.setBounds(50, 40, 15, 15);
		panel.add(onlinestatus);
		profilepiclabel = new JLabel("");
		
		profilepiclabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		profilepiclabel.setHorizontalAlignment(SwingConstants.CENTER);
		profilepiclabel.setBounds(15, 5, 50, 50);
		panel.add(profilepiclabel);

	}
	
	private class MyDocumentListener implements DocumentListener {
	    public void insertUpdate(DocumentEvent e) {
	        updateLog(e, "inserted into");
	    }
	    public void removeUpdate(DocumentEvent e) {
	        updateLog(e, "removed from");
	    }
	    public void changedUpdate(DocumentEvent e) {
	        //Plain text components do not fire these events
	    }
	    public void updateLog(DocumentEvent e, String action)
	    {
	        Document doc = (Document)e.getDocument();
	        if(doc.getLength()==0)
	        {
	        	hintlabel.setVisible(true);
	        }
	        else
	        {
	        	hintlabel.setVisible(false);
	        }
	        try 
	        {
	        	contactlistpanel.filterContact(doc.getText(0, doc.getLength()));
			} 
	        catch (BadLocationException e1) {
				e1.printStackTrace();
			}
	    }
	   }
}

